void minVertexCover(int **matrix, int vertex);
